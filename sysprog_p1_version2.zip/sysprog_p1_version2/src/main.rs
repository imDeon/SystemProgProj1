use std::fs;
use std::sync::mpsc;
use std::thread;
use std::time::Instant;
use std::path::Path;
use std::io::Write;
use sysprog_p1_version2::process_input_file; // Import the existing function

fn main() {
    // Initializes logger
    env_logger::init();

    let output_folder = "data/weekly_summary";
    if !Path::new(output_folder).exists() {
        fs::create_dir(output_folder).unwrap();
    }

    // Fetch all actual branch folders inside the "data" directory
    let branch_folders: Vec<String> = fs::read_dir("data")
        .unwrap()
        .filter_map(|entry| {
            let entry = entry.unwrap();
            if entry.file_type().unwrap().is_dir() {
                Some(entry.path().to_string_lossy().to_string())
            } else {
                None
            }
        })
        .collect();

    let (tx, rx) = mpsc::channel();
    let mut handles = vec![];

    let start_time = Instant::now();

    // 4 threads created
    for chunk in branch_folders.chunks(10) {
        let tx_clone = tx.clone();
        let chunk = chunk.to_vec();

        let handle = thread::spawn(move || {
            let result = process_branch_files(&chunk); // Call the renamed function
            for res in result {
                if let Err(e) = tx_clone.send(res) {
                    log::error!("Failed to send message: {}", e);
                }
            }
        });

        handles.push(handle);
    }

    // Wait for threads to finish
    for handle in handles {
        handle.join().unwrap();
    }

    drop(tx);

    let mut output_file = fs::File::create(format!("{}/weekly_sales_summary.txt", output_folder)).unwrap();

    // Process messages from the threads
    for received in rx {
        writeln!(output_file, "{}", received).unwrap();
        println!("{}", received);
    }

    let duration = start_time.elapsed();
    println!("Total time: {:?}", duration);
    println!("Phew! I am done.");
}

fn process_branch_files(branch_folders: &[String]) -> Vec<String> {
    let mut results = vec![];

    for folder in branch_folders {
        // Extract the last part of the folder name to check if it's the "weekly_summary"
        let branch_folder_name = folder
            .split('/')
            .last()
            .expect("Invalid folder path");

        // Handle weekly_summary differently
        let file_path = if branch_folder_name == "weekly_summary" {
            format!("{}/weekly_sales_summary.txt", folder)
        } else {
            format!("{}/branch_weekly_sales.txt", folder)
        };

        // Try opening the correct file for the folder
        match fs::read_to_string(&file_path) {
            Ok(contents) => {
                // Process the file contents and push results
                for line in contents.lines() {
                    results.push(line.to_string());
                }
            }
            Err(e) => {
                log::error!("Could not open file: {}", file_path);
            }
        }
    }

    results
}
