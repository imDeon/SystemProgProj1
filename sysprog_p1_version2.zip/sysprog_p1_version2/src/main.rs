use std::collections::HashMap;
use std::fs;
use std::sync::mpsc;
use std::thread;
use std::time::Instant;
use std::path::Path;
use std::io::Write;
use sysprog_p1_version2::process_input_file;

// Luke

fn main() {
    env_logger::init();

    let output_folder = "data/weekly_summary";
    if !Path::new(output_folder).exists() {
        fs::create_dir(output_folder).unwrap();
    }

    let branch_folders: Vec<String> = fs::read_dir("data")
        .unwrap()
        .filter_map(|entry| {
            let entry = entry.unwrap();
            // Ensure only directories are selected, and exclude 'weekly_summary'
            if entry.file_type().unwrap().is_dir() && entry.file_name() != "weekly_summary" {
                Some(entry.path().to_string_lossy().to_string())
            } else {
                None
            }
        })
        .collect();

    let (tx, rx) = mpsc::channel();
    let mut handles = vec![];

    let start_time = Instant::now();

    for chunk in branch_folders.chunks(10) {
        let tx_clone = tx.clone();
        let chunk = chunk.to_vec();

        let handle = thread::spawn(move || {
            let result = process_input_file(&chunk);
            if let Err(e) = tx_clone.send(result) {
                log::error!("Failed to send message: {}", e);
            }
        });

        handles.push(handle);
    }

    for handle in handles {
        handle.join().unwrap();
    }

    drop(tx);

    let mut totals: HashMap<(String, String), i32> = HashMap::new();

    for received in rx {
        // Combine totals from all threads
        for (key, qty) in received {
            let entry = totals.entry(key).or_insert(0);
            *entry += qty;
        }
    }

    let mut output_file = fs::File::create(format!("{}/weekly_sales_summary.txt", output_folder)).unwrap();

    for ((branch_code, product_code), total_quantity) in totals {
        writeln!(output_file, "{}, {}, {}", branch_code, product_code, total_quantity).unwrap();
    }

    let duration = start_time.elapsed();
    println!("Total time: {:?}", duration);
    println!("Phew! I am done.");
}
