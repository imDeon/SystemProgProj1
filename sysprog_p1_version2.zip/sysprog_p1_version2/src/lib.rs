use std::fs;
use std::io::{self, BufRead};
use log::error;

pub fn process_input_file(folders: &[String]) -> Vec<String> {
    let mut results = Vec::new();

    for folder in folders {
        let file_path = format!("{}/branch_weekly_sales.txt", folder);
        if let Ok(file) = fs::File::open(&file_path) {
            let reader = io::BufReader::new(file);
            let mut total_quantity = 0;
            let mut branch_code = String::new();
            let mut product_code = String::new();

            for (index, line) in reader.lines().enumerate() {
                if let Ok(data) = line {
                    let parts: Vec<&str> = data.split(",").collect();
                    if index == 0 {
                        branch_code = parts[0].to_string();
                        product_code = parts[1].to_string();
                    }
                    total_quantity += parts[2].trim().parse::<i32>().unwrap_or(0);
                }
            }

            let result = format!("{}, {}, {}", branch_code, product_code, total_quantity);
            results.push(result);
        } else {
            error!("Could not open file: {}", file_path);
        }
    }

    results
}

pub fn process_weekly_summary(folder: &str) -> Result<String, io::Error> {
    let file_path = format!("{}/weekly_sales_summary.txt", folder);
    
    if let Ok(file) = fs::File::open(&file_path) {
        let reader = io::BufReader::new(file);
        let mut total_quantity = 0;
        let mut branch_code = String::new();
        let mut product_code = String::new();

        for (index, line) in reader.lines().enumerate() {
            if let Ok(data) = line {
                let parts: Vec<&str> = data.split(",").collect();
                if index == 0 {
                    branch_code = parts[0].to_string();
                    product_code = parts[1].to_string();
                }
                total_quantity += parts[2].trim().parse::<i32>().unwrap_or(0);
            }
        }

        let result = format!("{}, {}, {}", branch_code, product_code, total_quantity);
        Ok(result)
    } else {
        error!("Could not open file: {}", file_path);
        Err(io::Error::new(io::ErrorKind::NotFound, "File not found"))
    }
}
