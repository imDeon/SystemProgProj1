use std::fs;
use std::io::{self, BufRead};
use log::error;
use std::collections::HashMap;

// Luke

pub fn process_input_file(folders: &[String]) -> HashMap<(String, String), i32> {
    let mut totals: HashMap<(String, String), i32> = HashMap::new(); // (branch_code, product_code) -> total_quantity - Luke

    // loop through the folders
    for folder in folders {
        let file_path = format!("{}/branch_weekly_sales.txt", folder);
        if let Ok(file) = fs::File::open(&file_path) {
            let reader = io::BufReader::new(file);

            for line in reader.lines() {
                if let Ok(data) = line {
                    let parts: Vec<&str> = data.split(",").collect();
                    if parts.len() >= 3 {
                        let branch_code = parts[0].to_string();
                        let product_code = parts[1].to_string();
                        let quantity = parts[2].trim().parse::<i32>().unwrap_or(0);

                        // Accumulate totals for all branches
                        let key = (branch_code.clone(), product_code.clone());
                        let entry = totals.entry(key).or_insert(0);
                        *entry += quantity;
                    }
                } else {
                    error!("Could not read line in file: {}", file_path); //error handling added for testing - Luke
                }
            }
        } else {
            error!("Could not open file: {}", file_path); //error handling added for testing - Luke
        }
    }
    //return totals to the weekly summary file - Luke 
    totals
}
